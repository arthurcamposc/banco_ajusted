package acesso_a_dado;

import java.sql.*;

public class AcessoADado {

    private Connection conn;

    public AcessoADado() {
        try {
            this.conn = ConexaoDB.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Connection getConnection() {
        return conn;
    }
}