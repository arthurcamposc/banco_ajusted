package acesso_a_dado;

import modelo.Fazenda;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FazendaDAO {

    private AcessoADado acessoADado;

    public FazendaDAO() {
        this.acessoADado = new AcessoADado();
    }

    public void cadastrar(Fazenda fazenda) {
        String query = "INSERT INTO fazenda (nome, email, saldo) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = acessoADado.getConnection().prepareStatement(query)) {
            pstmt.setString(1, fazenda.getNome());
            pstmt.setString(2, fazenda.getEmail());
            pstmt.setFloat(3, fazenda.getSaldo());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Fazenda> listar() {
        List<Fazenda> fazendas = new ArrayList<>();
        String query = "SELECT * FROM fazenda";
        try (Statement stmt = acessoADado.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Fazenda fazenda = new Fazenda(rs.getString("nome"), rs.getString("email"), rs.getFloat("saldo"));
                fazendas.add(fazenda);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return fazendas;
    }
}