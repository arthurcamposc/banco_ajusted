package acesso_a_dado;

import java.sql.*;
import java.util.Properties;

public class ConexaoDB {

    private static final String URL = "jdbc:postgresql://localhost:5432/seu_banco";
    private static final String USER = "seu_usuario";
    private static final String PASSWORD = "sua_senha";

    public static Connection getConnection() throws SQLException {
        Properties props = new Properties();
        props.setProperty("user", USER);
        props.setProperty("password", PASSWORD);
        return DriverManager.getConnection(URL, props);
    }
}