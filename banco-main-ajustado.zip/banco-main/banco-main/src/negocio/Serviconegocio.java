package negocio;

import acesso_a_dado.FazendaDAO;
import modelo.Fazenda;
import java.util.List;

public class ServiçoNegocio {

    private FazendaDAO fazendaDAO;

    public ServiçoNegocio() {
        this.fazendaDAO = new FazendaDAO();
    }

    public void cadastrarFazenda(Fazenda fazenda) {
        fazendaDAO.cadastrar(fazenda);
    }

    public List<Fazenda> listarFazendas() {
        return fazendaDAO.listar();
    }
}