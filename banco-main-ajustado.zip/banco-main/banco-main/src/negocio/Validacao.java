package negocio;

import java.util.regex.Pattern;

public class Validacao {

    public static boolean validarEmail(String email) {
        String regex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return Pattern.matches(regex, email);
    }

    public static boolean validarSaldo(float saldo) {
        return saldo >= 0;
    }
}