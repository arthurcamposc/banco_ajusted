package apresentacao;

public class Main {

    public static void main(String[] args) {
        // Cria uma instância da View, que vai controlar a interação com o usuário
        View view = new View();
        
        // Inicia a aplicação, chamando o método que exibe o menu e interage com o usuário
        view.iniciar();
    }
}
