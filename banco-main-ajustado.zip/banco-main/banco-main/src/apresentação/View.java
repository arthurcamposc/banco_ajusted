package apresentacao;

import java.util.Scanner;

public class View {

    private Scanner scanner;
    private Controlador controlador;

    public View() {
        scanner = new Scanner(System.in);
        controlador = new Controlador();
    }

    public void iniciar() {
        System.out.println("Bem-vindo ao sistema de fazendas!");
        int opcao;
        do {
            System.out.println("1 - Cadastrar Fazenda");
            System.out.println("2 - Listar Fazendas");
            System.out.println("0 - Sair");
            opcao = scanner.nextInt();
            scanner.nextLine();  // Consome o newline após o inteiro

            switch (opcao) {
                case 1:
                    System.out.print("Nome da Fazenda: ");
                    String nome = scanner.nextLine();
                    System.out.print("Email: ");
                    String email = scanner.nextLine();
                    System.out.print("Saldo: ");
                    float saldo = scanner.nextFloat();
                    controlador.cadastrarFazenda(nome, email, saldo);
                    break;
                case 2:
                    controlador.listarFazendas();
                    break;
            }
        } while (opcao != 0);
    }

    public static void main(String[] args) {
        View view = new View();
        view.iniciar();
    }
}