package apresentacao;

import negocio.ServiçoNegocio;
import modelo.Fazenda;
import java.util.List;

public class Controlador {

    private ServiçoNegocio servicoNegocio;

    public Controlador() {
        this.servicoNegocio = new ServiçoNegocio();
    }

    public void cadastrarFazenda(String nome, String email, float saldo) {
        Fazenda fazenda = new Fazenda(nome, email, saldo);
        servicoNegocio.cadastrarFazenda(fazenda);
    }

    public void listarFazendas() {
        List<Fazenda> fazendas = servicoNegocio.listarFazendas();
        for (Fazenda fazenda : fazendas) {
            System.out.println(fazenda);
        }
    }
}